package HotelBook;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
public static WebDriver webdriver;
	
	@Before
	public void setUp() {

		System.setProperty("webdriver.chrome.driver","D:\\selenium\\chromedriver.exe");
		webdriver=new ChromeDriver();
}

	@Given("^open Hotel Booking page$")
	public void open_Hotel_Booking_page() throws Throwable {
		webdriver.get("http://localhost:8081/HotelBooking/hotelbooking.html");
		/*String title = webdriver.findElement(By.xpath("/html/head/title")).getText();
		assertEquals("Hotel Booking",title);*/
		assertEquals("Hotel Booking", webdriver.getTitle());
	}

	@Given("^Personel and payment details$")
	public void personel_and_payment_details() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Curren");
		webdriver.findElement(By.name("txtLN")).sendKeys("Sam");
		webdriver.findElement(By.name("Email")).sendKeys("sam@gmail.com");
		webdriver.findElement(By.name("Phone")).sendKeys("9955115599");
		webdriver.findElement(By.xpath("/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("Sirisilla");
		WebElement mySelectElement = webdriver.findElement(By.name("city"));
		Select dropdown= new Select(mySelectElement);
		dropdown.selectByVisibleText("Hyderabad");
		WebElement mySelectstate = webdriver.findElement(By.name("state"));
		Select dropdownState= new Select(mySelectstate);
		dropdownState.selectByVisibleText("Telangana");
		WebElement persons = webdriver.findElement(By.name("persons"));
		Select dropdownpersons= new Select(persons);
		dropdownpersons.selectByVisibleText("2");
		
		webdriver.findElement(By.xpath("//*[@id=\"txtCardholderName\"]")).sendKeys("sam");
		webdriver.findElement(By.name("debit")).sendKeys("321568974512");
		webdriver.findElement(By.name("cvv")).sendKeys("123");
		webdriver.findElement(By.name("month")).sendKeys("10");
		webdriver.findElement(By.name("year")).sendKeys("2023");
		
	}

	@When("^Personel And payment details are not empty$")
	public void personel_And_payment_details_are_not_empty() throws Throwable {
		WebElement confirm=webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]"));
		confirm.click();
	}

	@Then("^navigate to success page$")
	public void navigate_to_success_page() throws Throwable {
		/*driver.navigate().to("http://localhost:8081/HotelBooking/success.html");*/
		System.out.println("Navigating to success page " + getClass());
	}

	@Given("^Personel and payment details are null$")
	public void personel_and_payment_details_are_null() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("");
	   
	}

	@When("^Personel And payment details are empty$")
	public void personel_And_payment_details_are_empty() throws Throwable {
		WebElement confirm=webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]"));
		confirm.click();
	}

	@Then("^show alert messages$")
	public void show_alert_messages() throws Throwable {
		String msg = webdriver.switchTo().alert().getText();
		assertEquals("Please fill the First Name",msg);
		Thread.sleep(1000);
		webdriver.switchTo().alert().accept();
	}
	
	@When("^Personel And payment details are empty with firstname$")
	public void personel_And_payment_details_are_empty_with_firstname() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Curren");
		WebElement confirm=webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]"));
		confirm.click();
	}

	@Then("^show alert messages after firstname$")
	public void show_alert_messages_after_firstname() throws Throwable {
		String msg1 = webdriver.switchTo().alert().getText();
		assertEquals("Please fill the Last Name",msg1);
		Thread.sleep(1000);
		webdriver.switchTo().alert().accept();
	}
	
	@When("^Personel And payment details are empty with lastname$")
	public void personel_And_payment_details_are_empty_with_lastname() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Curren");
		webdriver.findElement(By.name("txtLN")).sendKeys("Sam");
		WebElement confirm=webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]"));
		confirm.click();
	}

	@Then("^show alert messages after lastname$")
	public void show_alert_messages_after_lastname() throws Throwable {
		String msg1 = webdriver.switchTo().alert().getText();
		assertEquals("Please fill the Email",msg1);
		Thread.sleep(1000);
		webdriver.switchTo().alert().accept();
	}

	@When("^Personel And payment details are empty with email$")
	public void personel_And_payment_details_are_empty_with_email() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Curren");
		webdriver.findElement(By.name("txtLN")).sendKeys("Sam");
		webdriver.findElement(By.name("Email")).sendKeys("sam@gmail.com");		
		WebElement confirm=webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]"));
		confirm.click();
	}

	@Then("^show alert messages after email$")
	public void show_alert_messages_after_email() throws Throwable {
		String msg1 = webdriver.switchTo().alert().getText();
		assertEquals("Please fill the Mobile No.",msg1);
		Thread.sleep(1000);
		webdriver.switchTo().alert().accept();
	}
	
	@When("^Personel And payment details with wrong mobileno$")
	public void personel_And_payment_details_with_wrong_mobileno() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Curren");
		webdriver.findElement(By.name("txtLN")).sendKeys("Sam");
		webdriver.findElement(By.name("Email")).sendKeys("sam@gmail.com");
		webdriver.findElement(By.name("Phone")).sendKeys("2555115599");		
		WebElement confirm=webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]"));
		confirm.click();
	}

	@Then("^show alert messages after wrong mobileno$")
	public void show_alert_messages_after_wrong_mobileno() throws Throwable {
		
		String msg1 = webdriver.switchTo().alert().getText();
		assertEquals("Please enter valid Contact no.",msg1);
		Thread.sleep(1000);
		webdriver.switchTo().alert().accept();
	}


	@When("^Personel And payment details are empty with mobileno$")
	public void personel_And_payment_details_are_empty_with_mobileno() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Curren");
		webdriver.findElement(By.name("txtLN")).sendKeys("Sam");
		webdriver.findElement(By.name("Email")).sendKeys("sam@gmail.com");
		webdriver.findElement(By.name("Phone")).sendKeys("9955115599");
		webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
	
	}

	@Then("^show alert messages after mobileno$")
	public void show_alert_messages_after_mobileno() throws Throwable {
		String msg1 = webdriver.switchTo().alert().getText();
		assertEquals("Please select city",msg1);
		Thread.sleep(1000);
		webdriver.switchTo().alert().accept();
	}
	

	@When("^Personel And payment details are empty with city$")
	public void personel_And_payment_details_are_empty_with_city() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Curren");
		webdriver.findElement(By.name("txtLN")).sendKeys("Sam");
		webdriver.findElement(By.name("Email")).sendKeys("sam@gmail.com");
		webdriver.findElement(By.name("Phone")).sendKeys("9555115599");
		webdriver.findElement(By.xpath("/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("Sirisilla");
		WebElement mySelectElement = webdriver.findElement(By.name("city"));
		Select dropdown= new Select(mySelectElement);
		dropdown.selectByVisibleText("Hyderabad");
		webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
	}

	@Then("^show alert messages after city$")
	public void show_alert_messages_after_city() throws Throwable {
		String msg1 = webdriver.switchTo().alert().getText();
		assertEquals("Please select state",msg1);
		Thread.sleep(1000);
		webdriver.switchTo().alert().accept();
	}

	@When("^Personel And payment details are empty with state$")
	public void personel_And_payment_details_are_empty_with_state() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Curren");
		webdriver.findElement(By.name("txtLN")).sendKeys("Sam");
		webdriver.findElement(By.name("Email")).sendKeys("sam@gmail.com");
		webdriver.findElement(By.name("Phone")).sendKeys("9555115599");
		webdriver.findElement(By.xpath("/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("Sirisilla");
		WebElement mySelectElement = webdriver.findElement(By.name("city"));
		Select dropdown= new Select(mySelectElement);
		dropdown.selectByVisibleText("Hyderabad");
		WebElement mySelectstate = webdriver.findElement(By.name("state"));
		Select dropdownState= new Select(mySelectstate);
		dropdownState.selectByVisibleText("Telangana");
		WebElement confirm=webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]"));
		confirm.click();
	}

	@Then("^show alert messages after state$")
	public void show_alert_messages_after_state() throws Throwable {
		String msg1 = webdriver.switchTo().alert().getText();
		assertEquals("Please fill the Card holder name",msg1);
		Thread.sleep(1000);
		webdriver.switchTo().alert().accept();
	}

	@When("^Personel And payment details are empty with card holder name$")
	public void personel_And_payment_details_are_empty_with_card_holder_name() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Curren");
		webdriver.findElement(By.name("txtLN")).sendKeys("Sam");
		webdriver.findElement(By.name("Email")).sendKeys("sam@gmail.com");
		webdriver.findElement(By.name("Phone")).sendKeys("9555115599");
		webdriver.findElement(By.xpath("/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("Sirisilla");
		WebElement mySelectElement = webdriver.findElement(By.name("city"));
		Select dropdown= new Select(mySelectElement);
		dropdown.selectByVisibleText("Hyderabad");
		WebElement mySelectstate = webdriver.findElement(By.name("state"));
		Select dropdownState= new Select(mySelectstate);
		dropdownState.selectByVisibleText("Telangana");
		WebElement persons = webdriver.findElement(By.name("persons"));
		Select dropdownpersons= new Select(persons);
		dropdownpersons.selectByVisibleText("2");
		
		webdriver.findElement(By.xpath("//*[@id=\"txtCardholderName\"]")).sendKeys("sam");
		webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
	}

	@Then("^show alert messages after card holder name$")
	public void show_alert_messages_after_card_holder_name() throws Throwable {
		String msg1 = webdriver.switchTo().alert().getText();
		assertEquals("Please fill the Debit card Number",msg1);
		Thread.sleep(1000);
		webdriver.switchTo().alert().accept();
	}

	@When("^Personel And payment details are empty with debit no$")
	public void personel_And_payment_details_are_empty_with_debit_no() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Curren");
		webdriver.findElement(By.name("txtLN")).sendKeys("Sam");
		webdriver.findElement(By.name("Email")).sendKeys("sam@gmail.com");
		webdriver.findElement(By.name("Phone")).sendKeys("9555115599");
		webdriver.findElement(By.xpath("/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("Sirisilla");
		WebElement mySelectElement = webdriver.findElement(By.name("city"));
		Select dropdown= new Select(mySelectElement);
		dropdown.selectByVisibleText("Hyderabad");
		WebElement mySelectstate = webdriver.findElement(By.name("state"));
		Select dropdownState= new Select(mySelectstate);
		dropdownState.selectByVisibleText("Telangana");
		WebElement persons = webdriver.findElement(By.name("persons"));
		Select dropdownpersons= new Select(persons);
		dropdownpersons.selectByVisibleText("2");
		
		webdriver.findElement(By.xpath("//*[@id=\"txtCardholderName\"]")).sendKeys("sam");
		webdriver.findElement(By.name("debit")).sendKeys("321568974512");
		WebElement confirm=webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]"));
		confirm.click();
	}

	@Then("^show alert messages after debit no$")
	public void show_alert_messages_after_debit_no() throws Throwable {
		String msg1 = webdriver.switchTo().alert().getText();
		assertEquals("Please fill the CVV",msg1);
		Thread.sleep(1000);
		webdriver.switchTo().alert().accept();
	}

	@When("^Personel And payment details are empty with cvv$")
	public void personel_And_payment_details_are_empty_with_cvv() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Curren");
		webdriver.findElement(By.name("txtLN")).sendKeys("Sam");
		webdriver.findElement(By.name("Email")).sendKeys("sam@gmail.com");
		webdriver.findElement(By.name("Phone")).sendKeys("9555115599");
		webdriver.findElement(By.xpath("/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("Sirisilla");
		WebElement mySelectElement = webdriver.findElement(By.name("city"));
		Select dropdown= new Select(mySelectElement);
		dropdown.selectByVisibleText("Hyderabad");
		WebElement mySelectstate = webdriver.findElement(By.name("state"));
		Select dropdownState= new Select(mySelectstate);
		dropdownState.selectByVisibleText("Telangana");
		WebElement persons = webdriver.findElement(By.name("persons"));
		Select dropdownpersons= new Select(persons);
		dropdownpersons.selectByVisibleText("2");
		
		webdriver.findElement(By.xpath("//*[@id=\"txtCardholderName\"]")).sendKeys("sam");
		webdriver.findElement(By.name("debit")).sendKeys("321568974512");
		webdriver.findElement(By.name("cvv")).sendKeys("123");
		webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
	}

	@Then("^show alert messages after cvv$")
	public void show_alert_messages_after_cvv() throws Throwable {
		String msg1 = webdriver.switchTo().alert().getText();
		assertEquals("Please fill expiration month",msg1);
		Thread.sleep(1000);
		webdriver.switchTo().alert().accept();
	}

	@When("^Personel And payment details are empty with exp month$")
	public void personel_And_payment_details_are_empty_with_exp_month() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Curren");
		webdriver.findElement(By.name("txtLN")).sendKeys("Sam");
		webdriver.findElement(By.name("Email")).sendKeys("sam@gmail.com");
		webdriver.findElement(By.name("Phone")).sendKeys("9555115599");
		webdriver.findElement(By.xpath("/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("Sirisilla");
		WebElement mySelectElement = webdriver.findElement(By.name("city"));
		Select dropdown= new Select(mySelectElement);
		dropdown.selectByVisibleText("Hyderabad");
		WebElement mySelectstate = webdriver.findElement(By.name("state"));
		Select dropdownState= new Select(mySelectstate);
		dropdownState.selectByVisibleText("Telangana");
		WebElement persons = webdriver.findElement(By.name("persons"));
		Select dropdownpersons= new Select(persons);
		dropdownpersons.selectByVisibleText("2");
		
		webdriver.findElement(By.xpath("//*[@id=\"txtCardholderName\"]")).sendKeys("sam");
		webdriver.findElement(By.name("debit")).sendKeys("321568974512");
		webdriver.findElement(By.name("cvv")).sendKeys("123");
		webdriver.findElement(By.name("month")).sendKeys("10");
		WebElement confirm=webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]"));
		confirm.click();
	}

	@Then("^show alert messages after exp month$")
	public void show_alert_messages_after_exp_month() throws Throwable {
		String msg1 = webdriver.switchTo().alert().getText();
		assertEquals("Please fill the expiration year",msg1);
		Thread.sleep(1000);
		webdriver.switchTo().alert().accept();
	}

	@When("^Personel And payment details are empty with exp year$")
	public void personel_And_payment_details_are_empty_with_exp_year() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Curren");
		webdriver.findElement(By.name("txtLN")).sendKeys("Sam");
		webdriver.findElement(By.name("Email")).sendKeys("sam@gmail.com");
		webdriver.findElement(By.name("Phone")).sendKeys("9555115599");
		webdriver.findElement(By.xpath("/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("Sirisilla");
		WebElement mySelectElement = webdriver.findElement(By.name("city"));
		Select dropdown= new Select(mySelectElement);
		dropdown.selectByVisibleText("Hyderabad");
		WebElement mySelectstate = webdriver.findElement(By.name("state"));
		Select dropdownState= new Select(mySelectstate);
		dropdownState.selectByVisibleText("Telangana");
		WebElement persons = webdriver.findElement(By.name("persons"));
		Select dropdownpersons= new Select(persons);
		dropdownpersons.selectByVisibleText("2");
		
		webdriver.findElement(By.xpath("//*[@id=\"txtCardholderName\"]")).sendKeys("sam");
		webdriver.findElement(By.name("debit")).sendKeys("321568974512");
		webdriver.findElement(By.name("cvv")).sendKeys("123");
		webdriver.findElement(By.name("month")).sendKeys("10");
		webdriver.findElement(By.name("year")).sendKeys("2023");
		
	}

	@Then("^confirm after exp year$")
	public void confirm_after_exp_year() throws Throwable {
		webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
		Thread.sleep(1000);

	}


	@After
	public void close() throws InterruptedException {
		Thread.sleep(1000);
	webdriver.quit();	
	}
}
