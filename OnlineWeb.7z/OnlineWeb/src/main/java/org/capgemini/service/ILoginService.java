package org.capgemini.service;

import org.capgemini.model.LoginClass;

public interface ILoginService {

	public boolean isValid(LoginClass lc);
}
