package org.capgemini.dao;

import org.capgemini.model.LoginClass;

public interface ILoginDao {

	public boolean isValid(LoginClass lc);
}
