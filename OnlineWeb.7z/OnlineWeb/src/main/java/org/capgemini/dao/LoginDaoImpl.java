package org.capgemini.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.capgemini.model.LoginClass;

public class LoginDaoImpl implements ILoginDao {

	@Override
	public boolean isValid(LoginClass lc) {
		String sql="Select * from logintable where username=? and password=?";
		System.out.println("Hii");
		try(PreparedStatement pst=getMysqlConnection().prepareStatement(sql);){
			
			pst.setString(1, lc.getUsername());
			pst.setString(2, lc.getPassword());
			ResultSet rs=pst.executeQuery();
			 if(rs.next()) {
				 return true;
			 }
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return false;
	}

	private Connection getMysqlConnection() {
		
		Connection con=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "root", "India123");
					return con;
		}catch(SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
}
