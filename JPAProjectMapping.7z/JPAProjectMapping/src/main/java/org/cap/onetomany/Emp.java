package org.cap.onetomany;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Emp {

	@Id
	private int empid;
	private String empName;
	private LocalDate joinDate;
	@ManyToOne
	@JoinColumn(name="dd")
	private Company company;

	public Emp(int empid, String empName, Company company) {
		super();
		this.empid = empid;
		this.empName = empName;
		this.company = company;
	}

	public Emp() {
		
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	
	public LocalDate getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(LocalDate joinDate) {
		this.joinDate = joinDate;
	}

	@Override
	public String toString() {
		return "Emp [empid=" + empid + ", empName=" + empName + ", company=" + company + "]";
	}
	
	
}
