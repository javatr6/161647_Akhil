package org.cap.onetomany;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {


		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		entityTransaction.begin();
		
		Company company1=new Company("TCS");
		Company company2=new Company("CAPGEMINI");
		Company company3=new Company("INFOSYS");
		Emp emp=new Emp(12345,"SAI Ganesh",company1);
		emp.setJoinDate(LocalDate.now());
		Emp emp1=new Emp(1001,"Mahesh",company2);
		emp1.setJoinDate(LocalDate.now());
		Emp emp2=new Emp(16164,"Curren",company3);
		emp2.setJoinDate(LocalDate.of(2013, 02, 23));
		Emp emp3=new Emp(789,"Sam",company1);
		
		entityManager.persist(company1);
		entityManager.persist(company2);
		entityManager.persist(company3);
		
		entityManager.persist(emp);
		entityManager.persist(emp1);
		entityManager.persist(emp2);
		entityManager.persist(emp3);
		
		
		entityTransaction.commit();
		entityManager.close();
	}

}
