package org.cap.onetomany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import javax.persistence.OneToMany;

@Entity
public class Company {

	@Id
	@GeneratedValue
	private int comId;
	private String comName;
	@OneToMany(mappedBy="company",targetEntity=Emp.class,cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	private List<Emp> employees=new ArrayList<>();

	public Company() {
		
	}
	public Company(String comName, List<Emp> employees) {
		super();
		this.comName = comName;
		this.employees = employees;
	}
	
	public Company(String comName) {
		this.comName = comName;
	}
	public int getComId() {
		return comId;
	}
	public void setComId(int comId) {
		this.comId = comId;
	}
	public String getComName() {
		return comName;
	}
	public void setComName(String comName) {
		this.comName = comName;
	}
	public List<Emp> getEmployees() {
		return employees;
	}
	public void setEmployees(List<Emp> employees) {
		this.employees = employees;
	}
	@Override
	public String toString() {
		return "Company [comId=" + comId + ", comName=" + comName + ", employees=" + employees + "]";
	}
	
	
	
}
