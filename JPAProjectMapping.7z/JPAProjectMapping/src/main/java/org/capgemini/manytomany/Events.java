package org.capgemini.manytomany;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Events {

	@Id
	private int eid;
	private String ename;
	private LocalDate edate;
	@ManyToMany
	@JoinTable(name="event_delegates",joinColumns= 
	{@JoinColumn(name="delegates")},inverseJoinColumns= {@JoinColumn(name="events")})
	private List<Delegates> delegates=new ArrayList<>();
	
	public Events() {
		
	}
	public Events(int eid, String ename, LocalDate edate, List<Delegates> delegates) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.edate = edate;
		this.delegates = delegates;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public LocalDate getEdate() {
		return edate;
	}
	public void setEdate(LocalDate edate) {
		this.edate = edate;
	}
	public List<Delegates> getDelegates() {
		return delegates;
	}
	public void setDelegates(List<Delegates> delegates) {
		this.delegates = delegates;
	}
	@Override
	public String toString() {
		return "Events [eid=" + eid + ", ename=" + ename + ", edate=" + edate + ", delegates=" + delegates + "]";
	}
	
	
	
}
