package org.capgemini.manytomany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Delegates {

	@Id
	private int dId;
	private String dName;
	@ManyToMany
	@JoinTable(name="event_delegates",joinColumns= 
	{@JoinColumn(name="events")},inverseJoinColumns= {@JoinColumn(name="delegates")})
	private List<Events> events=new ArrayList<>();
	public Delegates() {
		
	}
	
	
	public Delegates(int dId, String dName) {
		super();
		this.dId = dId;
		this.dName = dName;
	}


	public Delegates(int dId, String dName, List<Events> events) {
		super();
		this.dId = dId;
		this.dName = dName;
		this.events = events;
	}
	public int getdId() {
		return dId;
	}
	public void setdId(int dId) {
		this.dId = dId;
	}
	public String getdName() {
		return dName;
	}
	public void setdName(String dName) {
		this.dName = dName;
	}
	public List<Events> getEvents() {
		return events;
	}
	public void setEvents(List<Events> events) {
		this.events = events;
	}
	@Override
	public String toString() {
		return "Delegates [dId=" + dId + ", dName=" + dName + ", events=" + events + "]";
	}
	
	
}
