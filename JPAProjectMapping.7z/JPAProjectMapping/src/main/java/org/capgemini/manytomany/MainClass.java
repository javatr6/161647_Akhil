package org.capgemini.manytomany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		entityTransaction.begin();
		Events java=new Events();
		java.setEid(101);
		java.setEname("JAVA");
		Events orc=new Events();
		orc.setEid(200);
		orc.setEname("ORACLE");
		Events pyt=new Events();
		pyt.setEid(203);
		pyt.setEname("PYTHON");
		
		Delegates delegates=new Delegates();
		delegates.setdId(987);
		delegates.setdName("Shiva K");
		
		Delegates delegates1=new Delegates(654,"Akhil");
		Delegates delegates2=new Delegates(123,"Akash");
		
		entityManager.persist(java);
		entityManager.persist(orc);
		entityManager.persist(pyt);
		
		delegates.getEvents().add(java);
		delegates1.getEvents().add(orc);
		delegates2.getEvents().add(pyt);
		
		entityManager.persist(delegates);
		entityManager.persist(delegates1);
		entityManager.persist(delegates2);
		
		
		entityTransaction.commit();
		entityManager.close();

	}

}
