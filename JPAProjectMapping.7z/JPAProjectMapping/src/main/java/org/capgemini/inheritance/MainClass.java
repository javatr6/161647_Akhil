package org.capgemini.inheritance;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		entityTransaction.begin();
		
		Project project=new Project(101,"JAVA_DOMAIN");
		Module module=new Module();
		module.setProid(111);
		module.setProName("DOTNET");
		module.setModName("M1");
		
		Task task=new Task();
		task.setProid(789);
		task.setProName("ORACLE");
		task.setModName("M2");
		task.setTaskName("ASSIGN");
		
		entityManager.persist(project);
		entityManager.persist(module);
		entityManager.persist(task);
		
		
		
		entityTransaction.commit();
		entityManager.close();

	}

}
