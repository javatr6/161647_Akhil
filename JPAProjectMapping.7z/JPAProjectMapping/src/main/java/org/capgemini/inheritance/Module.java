package org.capgemini.inheritance;

import javax.persistence.Entity;

@Entity
public class Module extends Project{

	
	private String modName;
	

	public Module() {
		super();
	}

	public Module(String modName) {
		super();
		this.modName = modName;
	}

	public String getModName() {
		return modName;
	}

	public void setModName(String modName) {
		this.modName = modName;
	}

	@Override
	public String toString() {
		return "Module [modName=" + modName + "]";
	}
	
}
