package org.capgemini.inheritance;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@Inheritance(strategy=InheritanceType.JOINED)
public class Project {

	@Id
	private int proid;
	private String proName;
	public Project() {
		
	}
	public Project(int proid, String proName) {
		super();
		this.proid = proid;
		this.proName = proName;
	}
	public int getProid() {
		return proid;
	}
	public void setProid(int proid) {
		this.proid = proid;
	}
	public String getProName() {
		return proName;
	}
	public void setProName(String proName) {
		this.proName = proName;
	}
	@Override
	public String toString() {
		return "Project [proid=" + proid + ", proName=" + proName + "]";
	}
	
}
