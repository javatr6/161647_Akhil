package org.capgemini.onetoone;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {

		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		entityTransaction.begin();
		
		Customer customer=new Customer("Abhi","Tom",1500.0);
		Address address=new Address(101,"MIPL",customer);
		
		Customer customer1=new Customer("Abhiram","Tom curren",21500.0);
		Address address1=new Address(1010,"Sipcot",customer1);
		
		entityManager.persist(customer);
		entityManager.persist(address);
		entityManager.persist(customer1);
		entityManager.persist(address1);
		
		entityTransaction.commit();
		entityManager.close();

	}

}
