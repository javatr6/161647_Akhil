package org.capgemini.jstl;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class datedemo extends SimpleTagSupport {

	String format;
	
	public void setFormat(String format) {
		this.format = format;
	}

	@Override
	public void doTag() throws JspException, IOException {
		
		JspWriter out=getJspContext().getOut();
		LocalDate date=LocalDate.now();
		DateTimeFormatter formatter =DateTimeFormatter.ofPattern(format);
		String d=date.format(formatter);
		out.print("<h1>"+d+"</h1>");
		
	}
}
